def quicktext():
    print('Hello, welcome to manzpy package.')